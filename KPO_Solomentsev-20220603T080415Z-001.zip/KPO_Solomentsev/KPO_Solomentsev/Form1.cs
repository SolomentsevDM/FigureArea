﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KPO_Solomentsev
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            listBox1.Hide();
            ToolTip tooltip = new ToolTip();
            tooltip.SetToolTip(CalcButton, "Рассчитать площадь по точкам");
        }
        class Shape
        {
            public List<Line>LinesList=new List<Line>();
            public double Square;
            public Shape() { }
            public Shape(List<Line> list)
            {
                foreach(var item in list)
                {
                    LinesList.Add(item);
                }
            }
            public void SquareCalc()
            {
                Square = 0;
                for(int i=0;i< LinesList.Count-1;i++)
                {
                    Square += LinesList[i].LineStartPoint.X * LinesList[i].LineEndPoint.Y;
                    Square -= LinesList[i].LineEndPoint.X * LinesList[i].LineStartPoint.Y;
                }
                Square += LinesList[LinesList.Count - 1].LineStartPoint.X * LinesList[0].LineStartPoint.Y- 
                    LinesList[LinesList.Count - 1].LineStartPoint.Y * LinesList[0].LineStartPoint.X;
                Square = Math.Abs(Square);
                Square /= 2.0;
            }
        }
        class Line
        {
            public Point LineStartPoint;
            public Point LineEndPoint;
            public Dictionary<int, Line> ConnectedLines = new Dictionary<int, Line>();
            public Line(Point Start,Point End)
            {
                LineStartPoint = Start;
                LineEndPoint = End;
            }
            public Line() { }
        }
        List<Line> LineShapesCycle = new List<Line>();
        List<Shape> Shapes = new List<Shape>();
        List<Line> Lines = new List<Line>();
        Line CurrentLine = new Line();
        bool CurrentLineClicked = false;
        List<int> CurrentShape = new List<int>();
        List<List<int>> AllShapes=new List<List<int>>();
        int StartLineIndex=0;
        private void PicturePaint(object sender, PaintEventArgs e)
        {
            textBox2.Clear();
            Pen pen = new Pen(Color.Black);
            foreach (var item in Lines)
            {
                e.Graphics.DrawLine(pen,item.LineStartPoint, item.LineEndPoint);
            }
            e.Graphics.DrawLine(pen, CurrentLine.LineStartPoint, CurrentLine.LineEndPoint);
        }
        private void PictureMouseDown(object sender, MouseEventArgs e)
        {
            CurrentLineClicked = true;
            CurrentLine.LineStartPoint.X = e.X;
            CurrentLine.LineStartPoint.Y = e.Y;
            Point NearestP = NearestPoint(e.X, e.Y);
            if (Math.Sqrt(Math.Pow((e.X - NearestP.X), 2) + Math.Pow((e.Y - NearestP.Y), 2)) < 10)
            {
                CurrentLine.LineStartPoint.X = NearestP.X;
                CurrentLine.LineStartPoint.Y = NearestP.Y;
            }
        }
        private void PictureMouseUp(object sender, MouseEventArgs e)
        {
            CurrentLineClicked = false;
            bool IsAdd = true;
            if(Math.Sqrt(Math.Pow((CurrentLine.LineStartPoint.X- CurrentLine.LineEndPoint.X),2)+ Math.Pow((CurrentLine.LineEndPoint.Y- CurrentLine.LineStartPoint.Y), 2))>10)
            {
                Lines.Add(new Line(CurrentLine.LineStartPoint, CurrentLine.LineEndPoint));
                for (int i = 0; i < Lines.Count - 1; i++)
                {
                    if (Lines[Lines.Count - 1].LineEndPoint == Lines[i].LineEndPoint && Lines[Lines.Count - 1].LineStartPoint == Lines[i].LineStartPoint ||
                        Lines[Lines.Count - 1].LineStartPoint == Lines[i].LineEndPoint && Lines[Lines.Count - 1].LineEndPoint == Lines[i].LineStartPoint)
                    {
                        Lines.Remove(Lines[Lines.Count - 1]);
                        IsAdd = false;
                        break;
                    }
                }
                if (IsAdd)
                {
                    for (int i = 0; i < Lines.Count - 1; i++)
                    {
                        if (Lines[Lines.Count - 1].LineEndPoint == Lines[i].LineEndPoint || Lines[Lines.Count - 1].LineEndPoint == Lines[i].LineStartPoint ||
                            Lines[Lines.Count - 1].LineStartPoint == Lines[i].LineEndPoint || Lines[Lines.Count - 1].LineStartPoint == Lines[i].LineStartPoint)
                        {
                            Lines[i].ConnectedLines.Add(Lines.Count - 1, Lines[Lines.Count - 1]);
                            Lines[Lines.Count - 1].ConnectedLines.Add(i, Lines[i]);
                        }
                    }
                    if (Lines.Count > 2)
                    {
                        LineCycle();
                    }
                }
            }
           
        }
        private void LineCycle()
        {
            Dictionary<int, Line> LinesShape2 = new Dictionary<int, Line>();
            foreach(var item in Lines)
            { 
                LinesShape2.Add(Lines.IndexOf(item), item);
            }
            bool IsChanged=true;
            while (IsChanged)
            {
                IsChanged = false;
                foreach (var item in LinesShape2)
                {
                    if (IsLineAlone(item.Value, LinesShape2))
                    {
                        LinesShape2.Remove(item.Key);
                        IsChanged = true;
                        break;
                    }
                }
            }
            if (LinesShape2.Count > 2)
            {
                int PrevCount= AllShapes.Count;
                foreach (var item in LinesShape2)
                {
                    StartLineIndex = item.Key;
                    ListLine(StartLineIndex, LinesShape2);
                }
                if (PrevCount< AllShapes.Count)
                {
                    listBox1.Show();
                    for(int i=PrevCount;i< AllShapes.Count;i++)
                    {
                        Shape shape = new Shape();
                        foreach (var dig in AllShapes[i])
                        {
                            shape.LinesList.Add(Lines[dig]);
                        }
                        LineSort(shape.LinesList);
                        Shapes.Add(shape);
                        shape.SquareCalc();
                        listBox1.Items.Add("Фигура " + " " + (i+1).ToString());
                    }
                }
            }
        }
        private void ListLine(int CurrentLineIndex, Dictionary<int, Line> LinesShape)
        {  
            foreach(var item in LinesShape[CurrentLineIndex].ConnectedLines)
            {
                if (LinesShape.ContainsKey(item.Key))
                {
                    if (!CurrentShape.Contains(item.Key))
                    {
                        CurrentShape.Add(CurrentLineIndex);
                        ListLine(item.Key, LinesShape);
                    }
                    if(item.Key== StartLineIndex&& CurrentShape.Count>=2)
                    {
                        CurrentShape.Add(CurrentLineIndex);
                        Dictionary<int, Line> TmpDict = new Dictionary<int, Line>();
                        Dictionary<int, Line> ShapeDict = new Dictionary<int, Line>();
                        foreach (var dig in CurrentShape)
                        {
                            TmpDict.Add(dig, Lines[dig]);
                            ShapeDict.Add(dig, Lines[dig]);
                        }
                        bool IsCorrect = true;
                        bool IsShape = true;
                        bool IsChanged = true;
                        ShapeDict.Remove(ShapeDict.First().Key);
                        while (IsChanged)
                        {
                            IsChanged = false;
                            foreach (var line in ShapeDict)
                            {
                                if (IsLineAlone(line.Value, ShapeDict))
                                {
                                    ShapeDict.Remove(line.Key);
                                    IsChanged = true;
                                    break;
                                }
                            }
                        }
                        if(ShapeDict.Count>0)
                        {
                            IsShape = false;
                        }
                        foreach (var line in TmpDict)
                        {
                            if (IsLineAlone(line.Value, TmpDict))
                            {
                                IsCorrect = false;
                                break;
                            }
                        }
                        if (IsCorrect&&IsShape)
                        {
                            List<int> tmp = new List<int>();
                            foreach (var dig in CurrentShape)
                            {
                                tmp.Add(dig);
                            }
                            tmp.Sort();
                            if (!AllShapesContains(tmp))
                            {
                                AllShapes.Add(new List<int>(tmp));
                            }
                        }
                        CurrentShape.RemoveAt(CurrentShape.Count - 1);
                    }
                }
            }
            if (CurrentShape.Count > 0)
            {
                CurrentShape.RemoveAt(CurrentShape.Count - 1);
            }
            return;
        }
        private bool AllShapesContains(List<int> CurrentShape)
        {
            foreach(var item in AllShapes)
            {
                if(item.SequenceEqual(CurrentShape))
                {
                    return true;
                }
            }
            return false;
        }
        private void LineSort(List<Line> list)
        {
            for(int i=0;i<list.Count-1;i++)
            {
                for (int j = i+1; j < list.Count; j++)
                {
                    if(list[i].LineEndPoint== list[j].LineEndPoint|| list[i].LineEndPoint == list[j].LineStartPoint)
                    {
                        if (list[i].LineEndPoint == list[j].LineStartPoint)
                        {
                            Line tmp = new Line();
                            tmp = list[i + 1];
                            list[i + 1] = list[j];
                            list[j] = tmp;
                            break;
                        }
                        else
                        {
                            Point Ptmp;
                            Ptmp=list[j].LineEndPoint;
                            list[j].LineEndPoint = list[j].LineStartPoint;
                            list[j].LineStartPoint = Ptmp;
                            Line tmp = new Line();
                            tmp = list[i + 1];
                            list[i + 1] = list[j];
                            list[j] = tmp;
                            break;
                        }
                    }
                }
            }
        }
        private bool IsLineAlone(Line line, Dictionary<int, Line> lines)
        {
            bool IsAlone=false;
            bool IsStartAlone = true;
            bool IsEndAlone = true;
            List<Line> lines1 = new List<Line> ();
            foreach(var item in lines)
            {
                lines1.Add(item.Value);
            }
            lines1.Remove(line);
            foreach (var item in lines1)
            {
                if(item.LineEndPoint==line.LineEndPoint|| item.LineStartPoint == line.LineEndPoint)
                {
                    IsEndAlone = false;
                }
                if (item.LineEndPoint == line.LineStartPoint || item.LineStartPoint == line.LineStartPoint)
                {
                    IsStartAlone = false;
                }
            }
            if(IsEndAlone|| IsStartAlone)
            {
                IsAlone = true;
            }
            return IsAlone;
        }
        private void PictureMouseMove(object sender, MouseEventArgs e)
        {
            if(CurrentLineClicked)
            {
                CurrentLine.LineEndPoint.X = e.X;
                CurrentLine.LineEndPoint.Y = e.Y;
                Point NearestP = NearestPoint(e.X, e.Y);
                if(Math.Sqrt(Math.Pow((e.X - NearestP.X), 2) + Math.Pow((e.Y - NearestP.Y), 2)) <10)
                {
                    CurrentLine.LineEndPoint.X = NearestP.X;
                    CurrentLine.LineEndPoint.Y = NearestP.Y;
                }
                pictureBox1.Invalidate();
            }
        }
        private Point NearestPoint(double X,double Y)
        {
            Point NearestPoint=new Point();
            double MinDistance = 1000;
            foreach (var item in Lines)
            {
                if(Math.Sqrt(Math.Pow((X-item.LineStartPoint.X),2)+ Math.Pow((Y - item.LineStartPoint.Y), 2))<MinDistance)
                {
                    MinDistance = Math.Sqrt(Math.Pow((X - item.LineStartPoint.X), 2) + Math.Pow((Y - item.LineStartPoint.Y), 2));
                    NearestPoint = item.LineStartPoint;
                }
                if (Math.Sqrt(Math.Pow((X - item.LineEndPoint.X), 2) + Math.Pow((Y - item.LineEndPoint.Y), 2)) < MinDistance)
                {
                    MinDistance = Math.Sqrt(Math.Pow((X - item.LineEndPoint.X), 2) + Math.Pow((Y - item.LineEndPoint.Y), 2));
                    NearestPoint = item.LineEndPoint;
                }
            }
            return NearestPoint;
        }
        private void ListBoxItemSelect(object sender, EventArgs e)
        {
            var g = pictureBox1.CreateGraphics();
            Pen pen = new Pen(Color.Black);
            Pen pen2 = new Pen(Color.Red);
            foreach (var item in Shapes)
            {
                foreach(var line in item.LinesList)
                {
                    g.DrawLine(pen, line.LineStartPoint, line.LineEndPoint);
                }
            }
            if (listBox1.SelectedItems.Count != 0)
            {
                int SelectedIndex = listBox1.SelectedIndex;
                textBox2.Text = Shapes[SelectedIndex].Square.ToString();
                foreach (var line in Shapes[SelectedIndex].LinesList)
                {
                    g.DrawLine(pen2, line.LineStartPoint, line.LineEndPoint);
                }
            }
        }

        private void CalcButtonClick(object sender, EventArgs e)
        {
            Form2 newForm = new Form2();
            newForm.Show();
        }
    }
}
