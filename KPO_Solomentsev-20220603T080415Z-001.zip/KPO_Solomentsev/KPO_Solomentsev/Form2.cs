﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KPO_Solomentsev
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            listView1.Hide();
        }
        bool IsPressed=false;
        int X;
        int Y;
        List<Point> points = new List<Point>();

        private void ButtonClick(object sender, EventArgs e)
        {
            if(Int32.TryParse(textBox3.Text,out X)&& Int32.TryParse(textBox4.Text, out Y))
            {
                listView1.Show();
                IsPressed = false;
                Point NewPoint = new Point(X, Y);
                if (points.Contains(NewPoint))
                {
                    MessageBox.Show("Данная точка уже существует");
                    textBox3.Clear();
                    textBox4.Clear();
                }
                else
                {
                    points.Add(NewPoint);
                    textBox3.Clear();
                    textBox4.Clear();
                    listView1.Items.Add("(" + NewPoint.X.ToString() + "; " + NewPoint.Y.ToString() + ")");
                }
            }
            else
            {
                MessageBox.Show("Значения точек должны быть целочисленными");
                textBox3.Clear();
                textBox4.Clear();
            }
        }

        private void CulcButtonClick(object sender, EventArgs e)
        {
            if(points.Count<3)
            {
                MessageBox.Show("Недостаточно точек для подсчета площади");
            }
            else
            {
                IsPressed = true;
                pictureBox1.Image = null;
                double Square = 0;
                for (int i = 0; i < points.Count - 1; i++)
                {
                    Square += points[i].X * points[i + 1].Y;
                    Square -= points[i + 1].X * points[i].Y;
                }
                Square += points[points.Count - 1].X * points[0].Y - points[points.Count - 1].Y * points[0].X;
                Square = Math.Abs(Square);
                Square /= 2.0;
                MessageBox.Show("Площадь фигуры равна: " + Square.ToString());
                Graphic();
            }
        }
        private void Graphic()
        {
            var g = pictureBox1.CreateGraphics();
            Pen pen = new Pen(Color.Black);
            for (int i = 0; i < points.Count - 1; i++)
            {
                g.DrawLine(pen, points[i], points[i + 1]);
            }
            g.DrawLine(pen, points[points.Count - 1], points[0]);
        }
        private void PictureBoxPaint(object sender, PaintEventArgs e)
        {
            if(IsPressed)
            {
                Pen pen = new Pen(Color.Black);
                for (int i = 0; i < points.Count - 1; i++)
                {
                    e.Graphics.DrawLine(pen, points[i], points[i + 1]);
                }
                e.Graphics.DrawLine(pen, points[points.Count - 1], points[0]);
            }
        }

        private void ClearButtonClick(object sender, EventArgs e)
        {
            IsPressed = false;
            points.Clear();
            listView1.Clear();
            pictureBox1.Image = null;
        }

        private void XKeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode==Keys.Enter)
            {
                e.SuppressKeyPress = true;
                if (textBox4.Text.Length == 0&& textBox3.Text.Length >0)
                {
                    textBox4.Focus();
                }
                else
                {
                    if(textBox4.Text.Length > 0 && textBox3.Text.Length > 0)
                    {
                        button1.PerformClick();
                    }
                }
            }
        }

        private void YKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                if (textBox3.Text.Length == 0&& textBox4.Text.Length > 0)
                {
                    textBox3.Focus();
                }
                else
                {
                    if (textBox4.Text.Length > 0 && textBox3.Text.Length > 0)
                    {
                        button1.PerformClick();
                    }
                }
            }
        }
    }
}
